import boto3
# Create an S3 client
s3 = boto3.client('s3')
# Specify the bucket name you wish to create
bucket_name = 'tracy-test-5678'
# Create the S3 bucket
try:
    s3.create_bucket(Bucket=bucket_name)
    print(f"Bucket '{bucket_name}' was successfully created.")
# Verify bucket existence
    response = s3.head_bucket(Bucket=bucket_name)
    print(f"Bucket '{bucket_name}' exists and is accessible.")
except Exception as e:
    print(f"An error occurred while creating the bucket: {e}")